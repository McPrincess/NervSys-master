**NervSys** is a simple Neuron Model controller and Nervous System for data processing based on php7.

Requirements: PHP7+ and above. Any kind of web server. MySQL, Redis and redis extention for PHP depand on yourself.
 
Datacenter are under construction, coming soon...

Demo module is out and opened here https://github.com/Jerry-Shaw/fruit. You can try it with NervSys with detailed comments in the picker.php

Sensor Module is opened for communication, https://github.com/Jerry-Shaw/sensor. Always needs developers.